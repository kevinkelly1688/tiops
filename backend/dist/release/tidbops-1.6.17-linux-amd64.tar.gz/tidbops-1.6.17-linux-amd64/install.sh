#!/usr/bin/env bash
# TiDB Ops 首次安装（本包架构：amd64）。
# 只做 root 与架构检查，实际逻辑在 Go 实现的 tidbops-server admin install 中。
set -euo pipefail

PKG_ARCH="amd64"

for a in "$@"; do
  case "$a" in -h|--help) SKIP_ROOT=1;; esac
done

if [ "$(id -u)" != "0" ] && [ -z "${SKIP_ROOT:-}" ]; then
  echo "错误: 需要 root 权限，请使用: sudo $0 $*" >&2
  exit 1
fi

case "$(uname -m)" in
  x86_64|amd64) MACHINE_ARCH="amd64";;
  aarch64|arm64) MACHINE_ARCH="arm64";;
  *) MACHINE_ARCH="$(uname -m)";;
esac
if [ "$MACHINE_ARCH" != "$PKG_ARCH" ]; then
  echo "错误: 本发布包适用于 $PKG_ARCH，当前机器架构是 $(uname -m)，请下载对应架构的包" >&2
  exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
ETC_DIR="/etc/tidb-ops"
PLATFORM_DRY=0
for a in "$@"; do
  case "$a" in -h|--help|-dry-run|--dry-run|-dry-run=true|--dry-run=true) PLATFORM_DRY=1;; esac
done
if [ "$PLATFORM_DRY" = "0" ] && [ -f "$HERE/deploy/ops/platform.json" ] && [ ! -e "$ETC_DIR/platform.json" ]; then
  install -d -m 0755 "$ETC_DIR"
  install -m 0644 "$HERE/deploy/ops/platform.json" "$ETC_DIR/platform.json"
  echo "已放置备案号配置文件 $ETC_DIR/platform.json：编辑其中的 icp，保存后执行 systemctl restart tidbops 生效"
fi
exec "$HERE/bin/tidbops-server" admin install --listen 0.0.0.0:8018 "$@"
