#!/usr/bin/env bash
# TiDB Ops 手动回滚到上一版本（本包架构：amd64）。
# 只做 root 与架构检查，实际逻辑在 Go 实现的 tidbops-server admin rollback 中。
set -euo pipefail

PKG_ARCH="amd64"

for a in "$@"; do
  case "$a" in -h|--help) SKIP_ROOT=1;; esac
done

if [ "$(id -u)" != "0" ] && [ -z "${SKIP_ROOT:-}" ]; then
  echo "错误: 需要 root 权限，请使用: sudo $0 $*" >&2
  exit 1
fi

case "$(uname -m)" in
  x86_64|amd64) MACHINE_ARCH="amd64";;
  aarch64|arm64) MACHINE_ARCH="arm64";;
  *) MACHINE_ARCH="$(uname -m)";;
esac
if [ "$MACHINE_ARCH" != "$PKG_ARCH" ]; then
  echo "错误: 本发布包适用于 $PKG_ARCH，当前机器架构是 $(uname -m)，请下载对应架构的包" >&2
  exit 1
fi

BIN="/opt/tidbops/current/bin/tidbops-server"
if [ ! -x "$BIN" ]; then
  echo "错误: 找不到 $BIN，平台尚未安装或安装目录不是默认的 /opt/tidbops" >&2
  exit 1
fi
exec "$BIN" admin rollback "$@"
